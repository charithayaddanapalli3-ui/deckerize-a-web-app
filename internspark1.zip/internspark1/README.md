# Dockerized Node.js Application

## Build Image

```bash
docker build -t docker-demo .
```

## Run Container

```bash
docker run -p 3000:3000 docker-demo
```

## Run Using Docker Compose

```bash
docker-compose up --build
```

## Test Application

Open:

http://localhost:3000

Expected Output:

Docker Container Running Successfully!